# Split ‘n’ Close

This is a Zendesk application that adds the ability to easily split a ticket off to another one and keep an association between the two.

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

### Screenshot(s):
[put your screenshots down here.]
